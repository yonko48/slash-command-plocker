const {
  Client,
  GatewayIntentBits,
  EmbedBuilder
} = require('discord.js');

const express = require('express');
const fs = require('fs');

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const TOKEN = 'PUT_TOKEN_HERE';
const PORT = 3000;
const LOG_CHANNEL_ID = 'PUT_LOG_CHANNEL_ID';

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

const DB_FILE = './database.json';

let db = {
  blockedCommands: [],
  blockedChannels: [],
  bypassRoles: []
};

if (fs.existsSync(DB_FILE)) {
  db = JSON.parse(fs.readFileSync(DB_FILE));
}

function saveDB() {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);
});

client.on('interactionCreate', async interaction => {

  if (!interaction.isChatInputCommand()) return;

  const cmd = interaction.commandName.toLowerCase();

  if (!db.blockedCommands.includes(cmd)) return;

  await interaction.reply({
    content: `❌ الأمر /${cmd} ممنوع هنا`,
    ephemeral: true
  });

  try {

    const logChannel =
      interaction.guild.channels.cache.get(
        LOG_CHANNEL_ID
      );

    if (logChannel) {

      const embed = new EmbedBuilder()
        .setTitle('Blocked Command Used')
        .addFields(
          {
            name: 'User',
            value: `${interaction.user.tag}`
          },
          {
            name: 'Command',
            value: `/${cmd}`
          }
        )
        .setTimestamp();

      logChannel.send({
        embeds: [embed]
      });

    }

  } catch {}

});

function htmlPage(content) {

  return `
  <html>

  <head>

    <title>Slash Blocker</title>

    <style>

      body{
        background:#0f1117;
        color:white;
        font-family:sans-serif;
        padding:40px;
      }

      .card{
        background:#1b1f2a;
        padding:20px;
        border-radius:20px;
        margin-bottom:20px;
      }

      input{
        padding:12px;
        width:300px;
        border:none;
        border-radius:10px;
      }

      button{
        padding:12px 20px;
        border:none;
        border-radius:10px;
        background:#5ea6ff;
        color:white;
        cursor:pointer;
      }

    </style>

  </head>

  <body>

    ${content}

  </body>

  </html>
  `;
}

app.get('/', (req, res) => {

  const commands =
    db.blockedCommands.map(c =>
      `<li>/${c}</li>`
    ).join('');

  res.send(htmlPage(`

    <h1>Discord Slash Blocker</h1>

    <div class="card">

      <h2>إضافة أمر ممنوع</h2>

      <form action="/add-command" method="POST">

        <input
          name="command"
          placeholder="kiss"
        >

        <button>
          إضافة
        </button>

      </form>

      <ul>${commands}</ul>

    </div>

  `));

});

app.post('/add-command', (req, res) => {

  const cmd =
    req.body.command
      .replace('/', '')
      .toLowerCase()
      .trim();

  if (
    cmd &&
    !db.blockedCommands.includes(cmd)
  ) {
    db.blockedCommands.push(cmd);
    saveDB();
  }

  res.redirect('/');
});

app.listen(PORT, () => {
  console.log(`Dashboard started on ${PORT}`);
});

client.login(TOKEN);
